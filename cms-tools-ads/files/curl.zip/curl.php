<?php
function geturl($url, $method = 'get', $header = null, $postdata = null, $new = false, $timeout = 15) {
        $s = curl_init();

        curl_setopt($s, CURLOPT_URL, $url);

        if ($header) {
            curl_setopt($s, CURLOPT_HTTPHEADER, $header);
        }

        curl_setopt($s, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($s, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($s, CURLOPT_MAXREDIRS, 5);
        curl_setopt($s, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($s, CURLOPT_FOLLOWLOCATION, true);

        if (strtolower($method) == 'post') {
            curl_setopt($s, CURLOPT_POST, true);
            curl_setopt($s, CURLOPT_POSTFIELDS, $postdata);
        } else if (strtolower($method) == 'delete') {
            curl_setopt($s, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($s, CURLOPT_CUSTOMREQUEST, 'DELETE');
        } else if (strtolower($method) == 'put') {
            curl_setopt($s, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($s, CURLOPT_POSTFIELDS, $postdata);
        }

        curl_setopt($s, CURLOPT_SSL_VERIFYPEER, false);

        $html = curl_exec($s);

        curl_close($s);
        return $html;
    }
 function user_profile() {
            $result = geturl("http://demo2.zingmobiledev.com/pos/test.php"); 
          return $result;
            }
            
            $fucntion=user_profile();
            print_r($fucntion);
?>